#include <stdio.h>
#include <stdlib.h>
#define SIZE 10


int main()
{
 
 int arr[SIZE];

 printf("Enter the 10 numbers:\n");

 for( int i=0; i<SIZE; i++)
 {
 	scanf("%d",&arr[i]);
 }

printf("Ascending Order is:\n");
ascending_order(arr);

printf("\nEven Numbers are :\n");
even_number(arr);
	
}

int ascending_order(int arr[SIZE])
{
	int temp;
	for( int i=0; i<SIZE; i++)
	{
		for(int j=i+1; j<SIZE; j++)
			{
				if(arr[i]>arr[j])
				{
					temp= arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
	}

	for(int i=0; i<SIZE; i++)
	{
		printf("%d\t", arr[i]);
	}
	return 0;
}


int even_number(int arr[SIZE])

{
	int arr_even[SIZE];
	for(int i=0; i<SIZE; i++)
	{
		if(arr[i]%2==0)
		{
			printf("%d\t",arr[i]);
		}
	}

	return 0;
}