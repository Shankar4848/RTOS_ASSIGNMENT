#include <stdio.h>
#include<stdlib.h>

int main()
{
	FILE *fp;
	int num;

	fp= fopen("input.txt","r");

	divisible_by_8(fp,num);
	multiply_by_2(fp,num);

}


void divisible_by_8(FILE *fp, int num)
{
	FILE *fo;
	fo= fopen("output.txt","w");
	while(fscanf(fp,"%d",&num) != -1)
	{
		if(num%8 == 0)
		{
			//fprintf(fo,"DIVISIBLE\t");
			fprintf(fo,"1\n");
		}
		else
		{
			//fprintf(fo,"NOT DIVISIBLE\t");
			fprintf(fo, "0\n");
		}
	}
}

void multiply_by_2(FILE *fp, int num)
{
	FILE *fd;
	fd= fopen("outputDouble.txt","w");

	while(fscanf(fp,"%d",&num)!= -1)
	{
		fprintf(fd,"%d\n",num*2);
	}
}