#include <stdio.h>
#include <stdlib.h>
#define NAME_LEN 20;

struct _directory_ {
	char first_name[NAME_LEN];
	char last_name[NAME_LEN];
	int phone_num;
}

}