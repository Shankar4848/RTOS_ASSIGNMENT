#include <stdio.h>
#define SIZE 10           
              //10 numbers from user
float sum(float a[]);
float average(float a[]);
float product(float a[]);

void main()
{
float a[SIZE];
int i;
printf("enter 10 numbers : ");
for(i=0;i<SIZE;i++)
    {
    scanf("%f",&a[i]);
    }
printf("\nthe sum of numbers is : %f",sum(a));  //printing sum
printf("\nthe average of the numbers is : %f",average(a));   //printing average
printf("\nthe product of the numbers is : %lf\n",product(a));   //printing product
}

float sum(float a[])
    {
    float sum=0;
    for(int i=0;i<SIZE;i++)
    {
        sum=sum+a[i];   //calculating sum of 10 user
    }
    return sum;
    }

float average(float a[])
    {
    float average;
    average=(sum(a)/SIZE);    //calculating average
    return average;
    }

float product(float a[])
    {
    float p=1;
    for(int i=0;i<SIZE;i++)    //calculating product
    {
        p=p*a[i];
    }
return p;
}