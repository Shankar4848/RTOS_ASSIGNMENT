#include<stdio.h>
#include<stdlib.h>

void main(int argc,char *argv[])
{
FILE *fp,*fpe,*fpo;
char ch[20];
int count=1;

fp=fopen(argv[1],"a");

if(fp==NULL)
    {
    printf("file doesnt exist");        
    exit(0);
    }

else
    {
    printf("file exists");
    }

fclose(fp);

fpe=fopen(argv[2],"w");
if(fpe==NULL)
    {
    printf("\neven.txt not created");
    exit(0);
    }
else
    printf("\neven.txt created");
fclose(fpe);

fpo=fopen(argv[3],"w");

if(fpo==NULL)
    {
    printf("\nodd.txt not created");
    exit(0);
    }
else
    printf("\nodd.txt created\n");

fclose(fpo);

fp=fopen(argv[1],"r");
fpe=fopen(argv[2],"w");
fpo=fopen(argv[3],"w");

while(fscanf(fp,"%s",ch)!=EOF)
{     //printf("%s",ch);
    if(count%2!=0)
        {
        fprintf(fpo,"%s\n",ch);
        count++;
        }
    else
        {
        fprintf(fpe,"%s\n",ch);
         count++;
    
        }
}

//printf("%d",count);
fclose(fp);
fclose(fpe);
fclose(fpo);
}