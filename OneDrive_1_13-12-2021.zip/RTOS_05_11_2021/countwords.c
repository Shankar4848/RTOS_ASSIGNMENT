#include <stdio.h>
#define SIZE 30
int word(FILE *fp);
int line(FILE *fp);
void main()
{
FILE *fp;
char s[SIZE];
fp=fopen("4s.txt","w");
if(fp==NULL)
    printf("file not created");
else
    {
    printf("file created successfully");
    printf("\n\nenter the text : ");
    fgets(s,SIZE,stdin);
    fputs(s,fp);
    }
fclose(fp);
fp=fopen("4s.txt","r");
printf("\nThe number of words in the file is : %d",word(fp));
fclose(fp);
fp=fopen("4s.txt","r");
printf("\nThe number of lines in the file is : %d",line(fp));
fclose(fp);
}
int word(FILE *fw)
{
char c;
int countword=0;
while((c=getc(fw))!=EOF)
    {
    if(c==' ')
    countword++;
    }
    fseek(fw,0,SEEK_SET);
    c=getc(fw);
    if(countword==1 && c==' ')
    return 0;
    else
    return countword+1;
}
int line(FILE *fl)
{
char c;
int countline=0;
while((c=getc(fl))!=EOF)
{
if(c=='\n')
countline++;
}
return countline;
}