#include<stdio.h>

int count(char *p)
{
    int count=0;
    for(int i=0;i<20;i++)

    if(*p!='\0')
    {
        count++;
         p++;
    }

     else
         break;
     return count;
}

void main()
{

FILE *fp;
char s[20];
fp=fopen("3_string.txt","w");
if(fp==NULL)
    printf("File not created");
else
    {
    printf("Enter the string : ");
    scanf("%s",s);
    fprintf(fp,"%s",s);
    printf("File created successfully");
    
     }

fclose(fp);

fp=fopen("3_string.txt","r");

fscanf(fp,"%s",s);
printf("\nThe String is : %s",s);
printf("\nThe Number of characters in string : %d",count(s));
fclose(fp);

}