#include<stdio.h>
#define SIZE 10

float sum(float a[]);
float average(float a[]);
float product(float a[]);
int i;

void main()
{
float a[SIZE];
printf("enter the numbers (enter 888 after last input) : ");
for(i=0;i<SIZE;i++)
{
    scanf("%f",&a[i]);
    if(a[i]==888)
    break;
}

printf("\nthe sum of numbers is : %0.2f",sum(a));    //printing sum
printf("\nthe average of the numbers is : %0.2f",average(a));         //printing average
printf("\nthe product of the numbers is : %0.2lf\n",product(a));     //printing product
}

float sum(float a[])
{
    float sum=0;
    for(int j=0;j<i;j++)
    {
        sum=sum+a[j];   //calculating sum of 10 user
    }
    return sum;
}

float average(float a[])
{
    float average;
    average=(sum(a)/i);   //calculating average
    return average;
}

float product(float a[])
{
    double p=1;
    for(int j=0;j<i;j++)
    {
    p=p*a[j];     //calculating product
    }
return p;
}
