#include<stdio.h>
#include<string.h>
#define size 1000

int main()
{
	FILE *fptr1;
	int i,j[10],count=0,k,l,p,m;
	char ch[size] ={'0'};
	
	

	fptr1 = fopen("text1.txt", "r");

	if(fptr1 == NULL)
		return -1;

	

	for(int i=0; i < 1000; i++)
	{
		
		ch[i] = fgetc(fptr1); //storing in an array
		if(ch[i] == EOF) //checking for end of file
			break;
	}

	for(int m=0; m < strlen(ch)-1;m++)
	{	
		if(ch[m] == ' ') // checking for space
		{ 	
			j[count] = m; //storing index value
			++count;
		}
		
	}
	


	for(int k=0; k<6; k+=2)
	{
			for(int p=j[k];p<j[k+1];p++)// printing from even space to odd space
			{
				//printf("-%d\n", j[k]);
				printf("%c", ch[p]); //
			}

		

	}

	return 0;
}