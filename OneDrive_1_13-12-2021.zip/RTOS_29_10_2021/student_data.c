#include <stdio.h> 
#include <stdlib.h> 
#define NAME_LEN 40 

 
int main() 

{ 
    FILE *fp; 

    fp= fopen("studentdetails.txt", "w"); 

    struct _student_{ 
    char name[NAME_LEN]; 
    int reg_no; 
    int marks[5]; 
    }; 

    typedef struct _student_ Student; 

    Student s; 

    int n; 

    printf("Enter the number of Students:\n"); 
    scanf("%d",&n); 

for(int i=0;i<n;i++)
{

    printf("\nEnter Student Roll Number:"); 
    scanf("%d",&s.reg_no); 
    fprintf(fp,"REGISTER NUMBER"); 
    fprintf(fp,"%d\n",s.reg_no); 

    printf("\nEnter Student name: "); 
    scanf("%s",s.name); 
    fprintf(fp,"NAME"); 
    fprintf(fp,"%s\n",s.name); 

    printf("\nEnter Student 5 subject's marks: "); 
    fprintf(fp,"MARKS"); 

    for(int j=0;j<5;j++) 
        { 
            scanf("%d",&s.marks[j]); 

            if(s.marks[j]<35) 
            { 
                fprintf(fp,"%d\t",s.marks[j]); 
                fprintf(fp,"FAIL"); 
            } 
            else 
            { 
                fprintf(fp,"%d\t",s.marks[j]); 
                fprintf(fp,"PASS"); 
            } 
        } 
    }

    fclose(fp); 
    return 0; 
}


    
