#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	FILE *feven,*fodd;
	char *even = "The Even Numbers are:\n";
	char *odd = "The Odd Numbers are:\n";


	feven= fopen("Even.txt","w");
	fodd= fopen("Odd.txt","w");

	fprintf(feven, "%s",even);

	fprintf(fodd, "%s",odd);

	for(int i=0; i<argc; i++)		
	{

		if(atoi(argv[i])%2==0)
		{	
			fprintf(feven,"%s\n",argv[i]);
		}

		else
			fprintf(fodd,"%s\n",argv[i]);	
	}		
fclose(feven);
fclose(fodd);

	return 0;
}