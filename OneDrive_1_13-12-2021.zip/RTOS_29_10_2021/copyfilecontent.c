#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("Program to copy the file contents from file1.txt to file2.txt\n");
	FILE *fs,*fd;
	char ch;

	fs= fopen("file1.txt","r");
	fd= fopen("file2.txt","w");

	if(fs == NULL)
		{
			printf("Error in opening the file\n");
		}

	while((ch = fgetc(fs))!= EOF)
		{			
			fputc(ch,fd);
		}

	fclose(fs);
	fclose(fd);
}