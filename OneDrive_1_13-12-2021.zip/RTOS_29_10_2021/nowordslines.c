#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("Program to count the number of words, number of lines, number of A, number of E, number of space\n");
	FILE *fp;
	char ch;
	int no_of_char=0, no_of_lines=0, no_of_A=0, no_of_E=0, no_of_space=0, no_of_words=0;

	fp = fopen("file1.txt","r");

	if(fp == NULL)

		{
			printf("Error in opening the file\n");
		}

	while((ch = fgetc(fp))!=EOF)
	{
		if(ch == '\n')
			no_of_lines++;
		if(ch == 'A')
			no_of_A++;
		if(ch == 'E')
			no_of_E++;
		if(ch == ' ')
			no_of_space++;

		if(ch == ' ' || ch == '\n' || ch == '\t')
			no_of_words++;
		}

	//printf("The Number of characters : %d\n", no_of_char);
	printf("The Number of lines : %d\n", no_of_lines);
	printf("The Number of A : %d\n", no_of_A);
	printf("The Number of E : %d\n", no_of_E);
	printf("The Number of space : %d\n", no_of_space);
	printf("The Number of words : %d\n", no_of_words);

	fclose(fp);
}
