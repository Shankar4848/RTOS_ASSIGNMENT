#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("Program to copy even numbered words to the targeted file.n");
	FILE *fs,*fd;
	char ch;
	//int no_of_words=0,no_of_char=0;

	fs = fopen("file1.txt","r");
	fd = fopen("file_copy1.txt","w");

	//if(fs == NULL)

		//{
			//printf("Error in opening the file\n");
		//}

		//char min_index= ch[0];


	while((ch = fgetc(fs))!=EOF)
	{
		//if((ch%2)==0)
		//{
			printf("%d", ch);
			fputc(ch,fd);
			ch= fgetc(fs);
		//}
	}
}


		/*
		if(ch == ' ' || ch == '\n' || ch == '\t')
			no_of_words++;
		}
		*/
	
